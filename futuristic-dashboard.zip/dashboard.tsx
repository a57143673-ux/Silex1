"use client"

import { useEffect, useState } from "react"
import {
  AlertCircle,
  BarChart3,
  Bell,
  Building2,
  CheckCircle,
  Clock,
  Download,
  Flag,
  Globe,
  Mail,
  Menu,
  MessageSquare,
  MoreVertical,
  Phone,
  ShoppingBag,
  Trash2,
  TrendingUp,
  Users,
  X,
  XCircle,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

// Mock data
const mockStats = [
  { label: "إجمالي المتاجر", value: "1,234", icon: Building2, trend: "+12%" },
  { label: "المستخدمين النشطين", value: "8,542", icon: Users, trend: "+23%" },
  { label: "الطلبات اليومية", value: "2,341", icon: ShoppingBag, trend: "+8%" },
  { label: "إجمالي الإيرادات", value: "45.2K", icon: TrendingUp, trend: "+15%" },
]

const mockStores = [
  { id: 1, name: "متجر الأزياء الفخمة", owner: "أحمد محمد", status: "نشط", sales: "12.5K", rating: 4.8 },
  { id: 2, name: "متجر الإلكترونيات", owner: "فاطمة علي", status: "نشط", sales: "8.3K", rating: 4.6 },
  { id: 3, name: "متجر الأغذية العضوية", owner: "محمد حسن", status: "معلق", sales: "2.1K", rating: 4.2 },
  { id: 4, name: "متجر الأثاث", owner: "سارة أحمد", status: "مرفوض", sales: "0", rating: 3.1 },
]

const mockUsers = [
  { id: 1, name: "علي كريم", email: "ali@email.com", purchases: 45, status: "نشط" },
  { id: 2, name: "أسماء عمر", email: "asma@email.com", purchases: 23, status: "نشط" },
  { id: 3, name: "محمود سالم", email: "mahmoud@email.com", purchases: 12, status: "محظور" },
  { id: 4, name: "دينا فارس", email: "dina@email.com", purchases: 67, status: "نشط" },
]

const mockComplaints = [
  { id: 1, type: "جودة المنتج", from: "علي كريم", about: "متجر الأزياء الفخمة", date: "2024-09-18", status: "جديد" },
  { id: 2, type: "تأخير التوصيل", from: "أسماء عمر", about: "متجر الإلكترونيات", date: "2024-09-17", status: "قيد الفحص" },
  { id: 3, type: "عدم الالتزام بالوصف", from: "محمود سالم", about: "متجر الأثاث", date: "2024-09-16", status: "مغلق" },
]

const mockReports = [
  { id: 1, title: "بيع منتجات مقلدة", reporter: "محمد حسن", store: "متجر الأزياء الفخمة", status: "جديد" },
  { id: 2, title: "محتوى غير لائق", reporter: "سارة أحمد", store: "متجر الأغذية العضوية", status: "قيد المراجعة" },
  { id: 3, title: "عملية احتيال", reporter: "أحمد علي", store: "متجر الإلكترونيات", status: "موثق" },
]

const mockPromotions = [
  { id: 1, title: "خصم 30% على الملابس", discount: "30%", status: "نشط", endDate: "2024-09-25" },
  { id: 2, title: "عرض شراء اثنين بسعر واحد", discount: "50%", status: "نشط", endDate: "2024-09-22" },
  { id: 3, title: "شحن مجاني على الطلبات فوق 100 ريال", discount: "مجاني", status: "منتهي", endDate: "2024-09-10" },
]

const mockAdApprovals = [
  { id: 1, title: "أسبوع العروض الكبرى", store: "متجر الأزياء الفخمة", channel: "إشعار + بريد", submitted: "منذ ساعتين" },
  { id: 2, title: "خصم العودة للمدارس", store: "متجر الإلكترونيات", channel: "إشعار التطبيق", submitted: "منذ 5 ساعات" },
  { id: 3, title: "توصيل مجاني لكل الطلبات", store: "متجر الأغذية العضوية", channel: "بث عام", submitted: "أمس" },
]

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [isLoading, setIsLoading] = useState(true)
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false)
  const [notificationsEnabled, setNotificationsEnabled] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 1000)
    return () => clearTimeout(timer)
  }, [])

  const StatCard = ({ stat }: { stat: typeof mockStats[0] }) => {
    const Icon = stat.icon
    return (
      <Card className="bg-white border-emerald-100 backdrop-blur-sm hover:bg-slate-900/70 transition-colors">
        <CardContent className="p-4">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-slate-700 text-sm mb-1">{stat.label}</p>
              <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
              <p className="text-green-400 text-xs mt-2">{stat.trend}</p>
            </div>
            <Icon className="h-8 w-8 text-cyan-500 opacity-20" />
          </div>
        </CardContent>
      </Card>
    )
  }

  const StatusBadge = ({ status }: { status: string }) => {
    const variants: { [key: string]: { bg: string; text: string } } = {
      "نشط": { bg: "bg-green-500/20", text: "text-green-400" },
      "معلق": { bg: "bg-yellow-500/20", text: "text-yellow-400" },
      "مرفوض": { bg: "bg-red-500/20", text: "text-red-400" },
      "جديد": { bg: "bg-blue-500/20", text: "text-blue-400" },
      "قيد الفحص": { bg: "bg-purple-500/20", text: "text-purple-400" },
      "مغلق": { bg: "bg-slate-500/20", text: "text-slate-700" },
      "محظور": { bg: "bg-red-500/20", text: "text-red-400" },
      "قيد المراجعة": { bg: "bg-orange-500/20", text: "text-orange-400" },
      "موثق": { bg: "bg-green-500/20", text: "text-green-400" },
      "منتهي": { bg: "bg-slate-500/20", text: "text-slate-700" },
    }
    const v = variants[status] || variants["نشط"]
    return (
      <Badge className={`${v.bg} ${v.text} border-0`}>
        {status}
      </Badge>
    )
  }

  return (
    <div className="min-h-screen bg-[#f5fffc] text-slate-900 font-[var(--font-tajawal)]">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-emerald-100 bg-white/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 bg-gradient-to-br from-emerald-400 to-teal-600 rounded-lg flex items-center justify-center">
                <Building2 className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                لوحة الإدارة
              </span>
            </div>

            <div className="relative flex items-center gap-2 sm:gap-4">
              <Button
                variant="outline"
                size="icon"
                aria-label="فتح أقسام اللوحة"
                onClick={() => setIsMenuOpen((open) => !open)}
                className="border-emerald-200 text-slate-800 hover:bg-emerald-50"
              >
                {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                aria-label={notificationsEnabled ? "فتح الإشعارات" : "تشغيل الإشعارات"}
                onClick={() => { setNotificationsEnabled(true); setIsNotificationsOpen((open) => !open) }}
                className="relative text-slate-800 hover:bg-emerald-50 hover:text-slate-950"
              >
                <Bell className="h-5 w-5" />
                {notificationsEnabled && <span className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full animate-pulse" />}
              </Button>
              <Avatar>
                <AvatarImage src="/placeholder.svg" alt="مدير النظام" />
                <AvatarFallback className="bg-emerald-500 text-white">إد</AvatarFallback>
              </Avatar>

              {isMenuOpen && (
                <div className="absolute left-0 top-12 z-50 w-64 rounded-xl border border-emerald-200 bg-white p-2 shadow-xl">
                  <p className="px-3 py-2 text-xs font-bold text-slate-600">الوصول السريع للأقسام</p>
                  {[
                    ["overview", "نظرة عامة"], ["stores", "إدارة المتاجر"], ["users", "المستخدمون"],
                    ["complaints", "الشكاوى والبلاغات"], ["ad-approvals", "موافقات الإعلانات"], ["settings", "الإعدادات"],
                  ].map(([value, label]) => (
                    <button key={value} type="button" onClick={() => { setActiveTab(value); setIsMenuOpen(false) }} className="flex w-full items-center rounded-lg px-3 py-2 text-right text-sm font-medium text-slate-800 transition hover:bg-emerald-50 hover:text-emerald-700">
                      {label}
                    </button>
                  ))}
                </div>
              )}
              {isNotificationsOpen && (
                <div className="absolute right-12 top-12 z-50 w-72 rounded-xl border border-emerald-200 bg-white p-4 shadow-xl">
                  <div className="flex items-center justify-between border-b border-emerald-100 pb-3">
                    <p className="font-bold text-slate-900">الإشعارات</p>
                    <span className="rounded-full bg-emerald-100 px-2 py-1 text-xs font-bold text-emerald-700">مفعّلة</span>
                  </div>
                  <p className="py-4 text-sm text-slate-700">لديك 3 طلبات إعلانية بانتظار المراجعة.</p>
                  <button type="button" onClick={() => setNotificationsEnabled(false)} className="text-xs font-bold text-red-600 hover:underline">إيقاف الإشعارات</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="container mx-auto px-4 py-6">
        {isLoading && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="flex flex-col items-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
              <p className="mt-4 text-emerald-600 font-mono">جاري التحميل...</p>
            </div>
          </div>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 bg-emerald-50/70 border border-emerald-100">
            <TabsTrigger value="overview" className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-600">
              نظرة عامة
            </TabsTrigger>
            <TabsTrigger value="stores" className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-600">
              المتاجر
            </TabsTrigger>
            <TabsTrigger value="users" className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-600">
              المستخدمون
            </TabsTrigger>
            <TabsTrigger value="complaints" className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-600">
              الشكاوى
            </TabsTrigger>
            <TabsTrigger value="ad-approvals" className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-600">
              موافقات الإعلانات
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-600">
              الإعدادات
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6 mt-6">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {mockStats.map((stat, idx) => (
                <StatCard key={idx} stat={stat} />
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Promotions */}
              <Card className="bg-white border-emerald-100 backdrop-blur-sm lg:col-span-1">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base text-slate-900">العروض الترويجية</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {mockPromotions.map((promo) => (
                    <div key={promo.id} className="flex items-center justify-between p-2 rounded bg-emerald-50/70 border border-emerald-100">
                      <div>
                        <p className="text-sm font-medium text-slate-900">{promo.title}</p>
                        <p className="text-xs text-slate-700">ينتهي: {promo.endDate}</p>
                      </div>
                      <StatusBadge status={promo.status} />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Recent Reports */}
              <Card className="bg-white border-emerald-100 backdrop-blur-sm lg:col-span-2">
                <CardHeader className="pb-3 flex flex-row items-center justify-between">
                  <CardTitle className="text-base text-slate-900">التقارير الأخيرة</CardTitle>
                  <Badge variant="outline" className="bg-red-500/20 text-red-400 border-0">
                    {mockReports.length} جديد
                  </Badge>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {mockReports.map((report) => (
                      <div key={report.id} className="flex items-center justify-between p-2 rounded bg-emerald-50/70 border border-emerald-100 text-sm">
                        <div className="flex-1">
                          <p className="font-medium text-slate-900">{report.title}</p>
                          <p className="text-xs text-slate-700">{report.store}</p>
                        </div>
                        <StatusBadge status={report.status} />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Complaints */}
            <Card className="bg-white border-emerald-100 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-slate-900 flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                  الشكاوى المستقبلة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-emerald-100">
                        <th className="text-left py-2 px-3 text-slate-700 font-medium">النوع</th>
                        <th className="text-right py-2 px-3 text-slate-700 font-medium">من</th>
                        <th className="text-right py-2 px-3 text-slate-700 font-medium">بخصوص</th>
                        <th className="text-center py-2 px-3 text-slate-700 font-medium">التاريخ</th>
                        <th className="text-center py-2 px-3 text-slate-700 font-medium">الحالة</th>
                        <th className="text-center py-2 px-3 text-slate-700 font-medium">الإجراء</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockComplaints.map((complaint) => (
                        <tr key={complaint.id} className="border-b border-slate-700/30 hover:bg-emerald-50/70 transition-colors">
                          <td className="py-3 px-3 text-slate-300">{complaint.type}</td>
                          <td className="py-3 px-3 text-slate-300">{complaint.from}</td>
                          <td className="py-3 px-3 text-slate-700 text-sm">{complaint.about}</td>
                          <td className="py-3 px-3 text-center text-slate-700 text-sm">{complaint.date}</td>
                          <td className="py-3 px-3 text-center">
                            <StatusBadge status={complaint.status} />
                          </td>
                          <td className="py-3 px-3 text-center">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                                <DropdownMenuItem className="text-slate-900 cursor-pointer">عرض</DropdownMenuItem>
                                <DropdownMenuItem className="text-slate-900 cursor-pointer">الرد</DropdownMenuItem>
                                <DropdownMenuItem className="text-slate-900 cursor-pointer">إغلاق</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Stores Tab */}
          <TabsContent value="stores" className="space-y-6 mt-6">
            <Card className="bg-white border-emerald-100 backdrop-blur-sm">
              <CardHeader className="pb-3 flex flex-row items-center justify-between">
                <CardTitle className="text-base text-slate-900">إدارة المتاجر</CardTitle>
                <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">متجر جد��د</Button>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {mockStores.map((store) => (
                    <div key={store.id} className="p-4 rounded-lg bg-emerald-50/70 border border-emerald-100 hover:border-cyan-500/50 transition-all">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="font-medium text-slate-900 text-sm">{store.name}</h3>
                          <p className="text-xs text-slate-700">{store.owner}</p>
                        </div>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                            <DropdownMenuItem className="text-slate-900 cursor-pointer">تعديل</DropdownMenuItem>
                            <DropdownMenuItem className="text-yellow-400 cursor-pointer">إيقاف مؤقت</DropdownMenuItem>
                            <DropdownMenuItem className="text-red-400 cursor-pointer">حذف</DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                      <div className="space-y-2 text-xs">
                        <div className="flex justify-between">
                          <span className="text-slate-700">المبيعات:</span>
                          <span className="text-slate-900">{store.sales}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-700">التقييم:</span>
                          <span className="text-yellow-400">⭐ {store.rating}</span>
                        </div>
                        <div className="pt-2">
                          <StatusBadge status={store.status} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6 mt-6">
            <Card className="bg-white border-emerald-100 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-slate-900">إدارة المستخدمين</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-emerald-100">
                        <th className="text-right py-3 px-3 text-slate-700 font-medium">الاسم</th>
                        <th className="text-right py-3 px-3 text-slate-700 font-medium">البريد الإلكتروني</th>
                        <th className="text-center py-3 px-3 text-slate-700 font-medium">المشتريات</th>
                        <th className="text-center py-3 px-3 text-slate-700 font-medium">الحالة</th>
                        <th className="text-center py-3 px-3 text-slate-700 font-medium">الإجراء</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockUsers.map((user) => (
                        <tr key={user.id} className="border-b border-slate-700/30 hover:bg-emerald-50/70 transition-colors">
                          <td className="py-3 px-3 text-slate-300">{user.name}</td>
                          <td className="py-3 px-3 text-slate-700">{user.email}</td>
                          <td className="py-3 px-3 text-center text-slate-900">{user.purchases}</td>
                          <td className="py-3 px-3 text-center">
                            <StatusBadge status={user.status} />
                          </td>
                          <td className="py-3 px-3 text-center">
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                                  <MoreVertical className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-slate-800 border-slate-700">
                                <DropdownMenuItem className="text-slate-900 cursor-pointer">عرض</DropdownMenuItem>
                                <DropdownMenuItem className="text-slate-900 cursor-pointer">إرسال رسالة</DropdownMenuItem>
                                {user.status !== "محظور" ? (
                                  <DropdownMenuItem className="text-red-400 cursor-pointer">حظر</DropdownMenuItem>
                                ) : (
                                  <DropdownMenuItem className="text-green-400 cursor-pointer">فك الحظر</DropdownMenuItem>
                                )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Complaints Tab */}
          <TabsContent value="complaints" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-white border-emerald-100">
                <CardContent className="p-4">
                  <div className="text-center">
                    <AlertCircle className="h-8 w-8 mx-auto text-red-500 mb-2" />
                    <p className="text-slate-700 text-sm">شكاوى جديدة</p>
                    <p className="text-2xl font-bold text-slate-900">12</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white border-emerald-100">
                <CardContent className="p-4">
                  <div className="text-center">
                    <Clock className="h-8 w-8 mx-auto text-yellow-500 mb-2" />
                    <p className="text-slate-700 text-sm">قيد المراجعة</p>
                    <p className="text-2xl font-bold text-slate-900">7</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-white border-emerald-100">
                <CardContent className="p-4">
                  <div className="text-center">
                    <CheckCircle className="h-8 w-8 mx-auto text-green-500 mb-2" />
                    <p className="text-slate-700 text-sm">مُغلقة</p>
                    <p className="text-2xl font-bold text-slate-900">34</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-white border-emerald-100 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-slate-900">جميع الشكاوى</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {mockComplaints.map((complaint) => (
                    <div key={complaint.id} className="p-3 rounded bg-emerald-50/70 border border-emerald-100 hover:border-cyan-500/50 transition-all">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="font-medium text-slate-900">{complaint.type}</p>
                          <p className="text-xs text-slate-700">من: {complaint.from} | حول: {complaint.about}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-slate-700">{complaint.date}</span>
                          <StatusBadge status={complaint.status} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Ad approvals tab */}
          <TabsContent value="ad-approvals" className="space-y-6 mt-6">
            <div className="flex flex-col gap-1">
              <h2 className="text-xl font-bold text-slate-900">موافقات بث الإعلانات الترويجية</h2>
              <p className="text-sm text-slate-700">راجع محتوى المتاجر قبل إرساله للعملاء عبر قنوات التواصل.</p>
            </div>
            <Card className="bg-white border-emerald-100">
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-base text-slate-900">طلبات البث المعلقة</CardTitle>
                  <p className="text-sm text-slate-700 mt-1">{mockAdApprovals.length} طلبات بانتظار قرار الإدارة</p>
                </div>
                <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">إنشاء بث جديد</Button>
              </CardHeader>
              <CardContent className="space-y-3">
                {mockAdApprovals.map((ad) => (
                  <div key={ad.id} className="flex flex-col gap-4 rounded-xl border border-emerald-100 bg-emerald-50/60 p-4 md:flex-row md:items-center md:justify-between">
                    <div>
                      <p className="font-semibold text-slate-900">{ad.title}</p>
                      <p className="text-sm text-slate-700">{ad.store} · {ad.channel} · {ad.submitted}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600"><CheckCircle className="ml-1 h-4 w-4" /> اعتماد وبث</Button>
                      <Button size="sm" variant="outline" className="border-red-200 text-red-600 hover:bg-red-50"><XCircle className="ml-1 h-4 w-4" /> رفض</Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Communication Settings */}
              <Card className="bg-white border-emerald-100 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base text-slate-900 flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-blue-500" />
                    التواصل
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 rounded bg-emerald-50/70 border border-emerald-100">
                    <p className="text-sm text-slate-700 mb-2">البريد الإلكتروني</p>
                    <p className="text-slate-900 font-mono text-sm">admin@app.com</p>
                  </div>
                  <div className="p-3 rounded bg-emerald-50/70 border border-emerald-100">
                    <p className="text-sm text-slate-700 mb-2">رقم الهاتف</p>
                    <p className="text-slate-900 font-mono text-sm">+966 50 123 4567</p>
                  </div>
                  <div className="p-3 rounded bg-emerald-50/70 border border-emerald-100">
                    <p className="text-sm text-slate-700 mb-2">الموقع الإلكتروني</p>
                    <p className="text-emerald-600 font-mono text-sm">www.app.com</p>
                  </div>
                  <Button className="w-full bg-emerald-500 hover:bg-emerald-600">تحديث</Button>
                </CardContent>
              </Card>

              {/* System Settings */}
              <Card className="bg-white border-emerald-100 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-base text-slate-900">إعدادات النظام</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 rounded bg-emerald-50/70 border border-emerald-100">
                    <span className="text-slate-300 text-sm">الوضع الظلام</span>
                    <input type="checkbox" className="w-4 h-4" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded bg-emerald-50/70 border border-emerald-100">
                    <span className="text-slate-300 text-sm">التنبيهات</span>
                    <input type="checkbox" className="w-4 h-4" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between p-3 rounded bg-emerald-50/70 border border-emerald-100">
                    <span className="text-slate-300 text-sm">التحديثات التلقائية</span>
                    <input type="checkbox" className="w-4 h-4" defaultChecked />
                  </div>
                  <Button className="w-full bg-emerald-100 hover:bg-slate-600">حفظ</Button>
                </CardContent>
              </Card>
            </div>

            {/* Data Export */}
            <Card className="bg-white border-emerald-100 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-slate-900">تصدير البيانات</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
                  <Button variant="outline" className="border-slate-300 text-slate-900 hover:bg-emerald-50">
                    <Download className="h-4 w-4 ml-2" /> المتاجر
                  </Button>
                  <Button variant="outline" className="border-slate-300 text-slate-900 hover:bg-emerald-50">
                    <Download className="h-4 w-4 ml-2" /> المستخدمون
                  </Button>
                  <Button variant="outline" className="border-slate-300 text-slate-900 hover:bg-emerald-50">
                    <Download className="h-4 w-4 ml-2" /> الطلبات
                  </Button>
                  <Button variant="outline" className="border-slate-300 text-slate-900 hover:bg-emerald-50">
                    <Download className="h-4 w-4 ml-2" /> التقارير
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
