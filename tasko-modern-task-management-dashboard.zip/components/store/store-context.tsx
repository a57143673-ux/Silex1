"use client"

import { createContext, useContext, useMemo, useState, type ReactNode } from "react"

export type Debtor = {
  id: string
  name: string
  phone: string
  amount: number
  date: string
  overdue: boolean
  paid: boolean
}

export type Product = {
  id: string
  name: string
  category: string
  stock: number
  max: number
  price: number
}

export type Campaign = {
  id: string
  title: string
  desc: string
  type: string
  active: boolean
}

export type Order = {
  id: string
  customer: string
  items: number
  total: number
  status: "مكتمل" | "قيد التجهيز" | "ملغى"
  time: string
}

type StoreContextValue = {
  debtors: Debtor[]
  products: Product[]
  campaigns: Campaign[]
  orders: Order[]
  query: string
  setQuery: (q: string) => void
  addDebtor: (d: Omit<Debtor, "id" | "paid">) => void
  collectDebt: (id: string) => void
  addProduct: (p: Omit<Product, "id">) => void
  restockProduct: (id: string, amount: number) => void
  addCampaign: (c: Omit<Campaign, "id">) => void
  toggleCampaign: (id: string) => void
  addOrder: (o: Omit<Order, "id" | "time">) => void
}

const StoreContext = createContext<StoreContextValue | null>(null)

let counter = 0
const uid = () => `id-${Date.now()}-${counter++}`

const initialDebtors: Debtor[] = [
  { id: uid(), name: "حسن علي", phone: "٠٧٧٠ ١٢٣ ٤٥٦", amount: 3200, date: "١٢ نيسان", overdue: true, paid: false },
  { id: uid(), name: "مروان قاسم", phone: "٠٧٥١ ٢٢٢ ٩٨٧", amount: 1850, date: "٢٠ نيسان", overdue: false, paid: false },
  { id: uid(), name: "سالم يوسف", phone: "٠٧٨٠ ٣٣٣ ١٢٣", amount: 900, date: "٢٥ نيسان", overdue: false, paid: false },
  { id: uid(), name: "أم كرار", phone: "٠٧٧١ ٤٤٤ ٥٥٥", amount: 2400, date: "٠٨ نيسان", overdue: true, paid: false },
  { id: uid(), name: "زينب حسن", phone: "٠٧٩٠ ٥٥٥ ٦٦٦", amount: 1200, date: "٢٨ نيسان", overdue: false, paid: false },
  { id: uid(), name: "علي محمود", phone: "٠٧٥٠ ٦٦٦ ٧٧٧", amount: 750, date: "٠٣ أيار", overdue: false, paid: false },
]

const initialProducts: Product[] = [
  { id: uid(), name: "رز عنبر ٥ كغم", category: "مواد غذائية", stock: 8, max: 100, price: 12000 },
  { id: uid(), name: "زيت دوار الشمس ١ لتر", category: "مواد غذائية", stock: 45, max: 120, price: 3500 },
  { id: uid(), name: "سكر ١ كغم", category: "مواد غذائية", stock: 0, max: 80, price: 1500 },
  { id: uid(), name: "شاي أحمر ٤٠٠ غم", category: "مشروبات", stock: 60, max: 100, price: 4000 },
  { id: uid(), name: "معجون طماطم", category: "مواد غذائية", stock: 12, max: 90, price: 1250 },
  { id: uid(), name: "حليب مجفف ٩٠٠ غم", category: "ألبان", stock: 30, max: 70, price: 8000 },
]

const initialCampaigns: Campaign[] = [
  { id: uid(), title: "خصم نهاية الأسبوع", desc: "خصم ١٥٪ على كل المواد الغذائية", type: "خصم", active: true },
  { id: uid(), title: "اشترِ ٢ واحصل على ١", desc: "على منتجات الألبان المختارة", type: "هدية", active: true },
  { id: uid(), title: "عرض الزبائن الجدد", desc: "توصيل مجاني لأول طلب", type: "توصيل", active: false },
  { id: uid(), title: "تخفيضات العيد", desc: "خصومات تصل إلى ٣٠٪", type: "خصم", active: false },
]

const initialOrders: Order[] = [
  { id: uid(), customer: "حسن علي", items: 5, total: 24000, status: "مكتمل", time: "قبل ١٠ دقائق" },
  { id: uid(), customer: "زينب حسن", items: 2, total: 8400, status: "قيد التجهيز", time: "قبل ٢٥ دقيقة" },
  { id: uid(), customer: "مروان قاسم", items: 8, total: 41000, status: "مكتمل", time: "قبل ساعة" },
  { id: uid(), customer: "أم كرار", items: 3, total: 12500, status: "ملغى", time: "قبل ساعتين" },
]

export function StoreProvider({ children }: { children: ReactNode }) {
  const [debtors, setDebtors] = useState<Debtor[]>(initialDebtors)
  const [products, setProducts] = useState<Product[]>(initialProducts)
  const [campaigns, setCampaigns] = useState<Campaign[]>(initialCampaigns)
  const [orders, setOrders] = useState<Order[]>(initialOrders)
  const [query, setQuery] = useState("")

  const value = useMemo<StoreContextValue>(
    () => ({
      debtors,
      products,
      campaigns,
      orders,
      query,
      setQuery,
      addDebtor: (d) => setDebtors((prev) => [{ ...d, id: uid(), paid: false }, ...prev]),
      collectDebt: (id) => setDebtors((prev) => prev.map((x) => (x.id === id ? { ...x, paid: true } : x))),
      addProduct: (p) => setProducts((prev) => [{ ...p, id: uid() }, ...prev]),
      restockProduct: (id, amount) =>
        setProducts((prev) =>
          prev.map((x) => (x.id === id ? { ...x, stock: Math.min(x.max, x.stock + amount) } : x)),
        ),
      addCampaign: (c) => setCampaigns((prev) => [{ ...c, id: uid() }, ...prev]),
      toggleCampaign: (id) =>
        setCampaigns((prev) => prev.map((x) => (x.id === id ? { ...x, active: !x.active } : x))),
      addOrder: (o) => setOrders((prev) => [{ ...o, id: uid(), time: "الآن" }, ...prev]),
    }),
    [debtors, products, campaigns, orders, query],
  )

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>
}

export function useStore() {
  const ctx = useContext(StoreContext)
  if (!ctx) throw new Error("useStore must be used within StoreProvider")
  return ctx
}

// Arabic-Indic digit formatting helpers
const arabicDigits = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"]
export function toArabicNumber(n: number): string {
  return n
    .toLocaleString("en-US")
    .replace(/,/g, "٬")
    .replace(/\d/g, (d) => arabicDigits[Number(d)])
}
export function formatIQD(n: number): string {
  return `${toArabicNumber(n)} د.ع`
}
